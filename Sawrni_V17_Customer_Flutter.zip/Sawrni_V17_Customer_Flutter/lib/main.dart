import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'sawrni_config.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Color(0xFF061426),
    statusBarIconBrightness: Brightness.light,
    navigationBarColor: Color(0xFFFFFFFF),
    navigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const SawrniCustomerApp());
}

class C {
  static const navy = Color(0xFF061426);
  static const navy2 = Color(0xFF0B1D35);
  static const purple = Color(0xFF6731C7);
  static const purple2 = Color(0xFF8D48FF);
  static const gold = Color(0xFFDCA83A);
  static const gold2 = Color(0xFFF4C65C);
  static const bg = Color(0xFFF6F7FB);
  static const ink = Color(0xFF101828);
  static const muted = Color(0xFF667085);
  static const line = Color(0xFFE6E9F0);
  static const green = Color(0xFF12A86B);
  static const red = Color(0xFFE34D62);
}

String fmt(dynamic n) {
  final x = int.tryParse('${n ?? 0}') ?? 0;
  return x.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
}

class Api {
  static Future<Map<String, dynamic>> get(String action, [Map<String, String>? q]) async {
    final uri = Uri.parse(SawrniConfig.apiBaseUrl).replace(queryParameters: {'action': action, ...?q});
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    final req = await client.getUrl(uri);
    final res = await req.close();
    final body = await res.transform(utf8.decoder).join();
    client.close();
    return jsonDecode(body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> post(String action, Map<String, dynamic> data) async {
    final uri = Uri.parse(SawrniConfig.apiBaseUrl).replace(queryParameters: {'action': action});
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    final req = await client.postUrl(uri);
    req.headers.contentType = ContentType.json;
    req.write(jsonEncode(data));
    final res = await req.close();
    final body = await res.transform(utf8.decoder).join();
    client.close();
    return jsonDecode(body) as Map<String, dynamic>;
  }
}

class SawrniCustomerApp extends StatelessWidget {
  const SawrniCustomerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'صورني',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: C.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: C.purple, brightness: Brightness.light),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: CustomerShell()),
    );
  }
}

class CustomerShell extends StatefulWidget { const CustomerShell({super.key}); @override State<CustomerShell> createState() => _CustomerShellState(); }
class _CustomerShellState extends State<CustomerShell> with TickerProviderStateMixin {
  int tab = 0;
  String category = 'graduation';
  String area = 'المنصور';
  String query = '';
  bool loading = true;
  String? error;
  List categories = [], sessions = [], providers = [], models = [], ads = [], areas = [], notifications = [], bookings = [];
  Set<String> favorites = {};
  late AnimationController pulse;

  @override void initState(){ super.initState(); pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse:true); loadAll(); }
  @override void dispose(){ pulse.dispose(); super.dispose(); }

  Future<void> loadAll() async {
    setState((){ loading = true; error = null; });
    try {
      final out = await Api.get('bootstrap', {'role':'customer','area':area,'category':category});
      final b = await Api.get('bookings', {'user_id': SawrniConfig.customerId});
      if(out['ok'] == true){
        final data = out['data'];
        setState((){
          categories = data['categories'] ?? [];
          sessions = data['sessions'] ?? [];
          providers = data['providers'] ?? [];
          models = data['models'] ?? [];
          ads = data['ads'] ?? [];
          areas = data['areas'] ?? [];
          notifications = data['notifications'] ?? [];
          favorites = Set<String>.from(data['favorites'] ?? []);
          bookings = b['ok'] == true ? (b['data'] ?? []) : [];
          loading = false;
        });
      } else { throw Exception(out['error'] ?? 'API failed'); }
    } catch (e) { setState((){ error = '$e'; loading = false; }); }
  }

  Future<void> runSearch(String text) async {
    setState(()=>query=text);
    if(text.trim().isEmpty){ await loadAll(); return; }
    try{
      final out = await Api.get('search', {'q': text, 'area': area, 'category': category});
      if(out['ok']==true){ final d=out['data']; setState((){ sessions=d['sessions']??[]; providers=d['providers']??[]; models=d['models']??[]; }); }
    }catch(_){ }
  }

  void selectCategory(String id){ setState(()=>category=id); loadAll(); }
  Future<void> toggleFavorite(String id) async { setState(()=> favorites.contains(id) ? favorites.remove(id) : favorites.add(id)); await Api.post('favorite', {'user_id':SawrniConfig.customerId,'item_id':id}); }
  Future<void> openLocation() async {
    final selected = await showModalBottomSheet<String>(context: context, backgroundColor: Colors.transparent, builder: (_) => LocationSheet(areas: areas, selected: area));
    if(selected!=null){ setState(()=>area=selected); await loadAll(); }
  }
  void openFilters() => showModalBottomSheet(context: context, backgroundColor: Colors.transparent, builder: (_) => FilterSheet(onApply: (cat, ar){ setState((){category=cat; area=ar;}); loadAll(); }, categories: categories, areas: areas, category: category, area: area));
  void notify() => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => NotificationSheet(items: notifications));
  void openFavorites() => Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: FavoritesPage(favorites: favorites, sessions: sessions, providers: providers, models: models, onFav: toggleFavorite))));

  Future<void> startBooking(Map session, [Map? provider]) async {
    final result = await showModalBottomSheet<Map<String,dynamic>>(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => BookingSheet(session: session, providers: providers, selectedProvider: provider, area: area));
    if(result != null){
      final out = await Api.post('create_booking', result);
      if(out['ok']==true){ await loadAll(); setState(()=>tab=3); toast('تم إرسال طلب الحجز للمصور'); } else { toast(out['error'] ?? 'لم يتم الحجز'); }
    }
  }
  void toast(String m){ ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating, backgroundColor: C.navy)); }

  @override Widget build(BuildContext context){
    return Scaffold(
      body: SafeArea(
        child: Stack(children:[
          if(loading) const Center(child: CircularProgressIndicator(color: C.purple))
          else if(error!=null) ErrorState(error: error!, onRetry: loadAll)
          else IndexedStack(index: tab, children:[
            HomePage(shell:this), SessionsPage(shell:this), ModelsPage(shell:this), BookingsPage(shell:this), AccountPage(shell:this)
          ]),
        ]),
      ),
      bottomNavigationBar: BottomNav(tab: tab, onTap: (i)=>setState(()=>tab=i)),
    );
  }
}

class BottomNav extends StatelessWidget { final int tab; final ValueChanged<int> onTap; const BottomNav({super.key,required this.tab,required this.onTap});
  @override Widget build(BuildContext context){
    final items = [ ['الرئيسية',Icons.home_rounded], ['الجلسات',Icons.camera_alt_rounded], ['الموديلز',Icons.groups_rounded], ['الحجوزات',Icons.calendar_month_rounded], ['حسابي',Icons.person_outline_rounded] ];
    return Container(
      margin: const EdgeInsets.fromLTRB(18,0,18,14), padding: const EdgeInsets.symmetric(horizontal:10,vertical:10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30), boxShadow:[BoxShadow(color: Colors.black.withOpacity(.10), blurRadius:30, offset: const Offset(0,12))]),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: List.generate(items.length,(i){
        final active = tab==i; return Expanded(child: InkWell(borderRadius: BorderRadius.circular(24), onTap:()=>onTap(i), child: AnimatedContainer(duration: const Duration(milliseconds:220), padding: const EdgeInsets.symmetric(vertical:10), decoration: BoxDecoration(color: active?C.purple.withOpacity(.10):Colors.transparent,borderRadius:BorderRadius.circular(22)), child: Column(mainAxisSize:MainAxisSize.min, children:[CircleAvatar(radius: active?22:17, backgroundColor: active?C.purple:Colors.transparent, child: Icon(items[i][1] as IconData, color: active?Colors.white:C.muted)), const SizedBox(height:4), Text(items[i][0] as String, style: TextStyle(fontSize:12,fontWeight:active?FontWeight.w900:FontWeight.w600,color:active?C.purple:C.muted))]))));
      })),
    );
  }
}

class HomePage extends StatelessWidget { final _CustomerShellState shell; const HomePage({super.key,required this.shell});
  @override Widget build(BuildContext context){
    final cat = shell.categories.cast<Map>().firstWhere((e)=>e['id']==shell.category, orElse:()=>{});
    return RefreshIndicator(onRefresh:shell.loadAll, color:C.purple, child: ListView(padding: EdgeInsets.zero, children:[
      AppHeader(shell:shell, title:'صورني', subtitle:'استوديو كامل بجيبك', showSearch:true),
      CategoryChips(categories:shell.categories, selected:shell.category, onTap:shell.selectCategory),
      ModelRow(
        models:shell.models,
        onTap:(m){
          showModalBottomSheet(
            context:context,
            isScrollControlled:true,
            backgroundColor:Colors.transparent,
            builder:(_)=>ModelProfile(
              model:m,
              onBook:()=>shell.startBooking(shell.sessions.isNotEmpty?shell.sessions.first:{}, null),
            ),
          );
        },
      ),
      HeroCarousel(ads:shell.ads, category:cat, sessions:shell.sessions, onBook:(){ if(shell.sessions.isNotEmpty) shell.startBooking(shell.sessions.first); }),
      SectionTitle(title:'جلسات مميزة', icon:Icons.auto_awesome, onAll:()=>shell.setState(()=>shell.tab=1)),
      HorizontalCards(items:shell.sessions, favorites:shell.favorites, onFav:shell.toggleFavorite, onTap:shell.startBooking),
      SectionTitle(title:'أفضل المصورين', icon:Icons.photo_camera_outlined, onAll:()=>shell.setState(()=>shell.tab=1)),
      PhotographerRow(providers:shell.providers, favorites:shell.favorites, onFav:shell.toggleFavorite, onTap:(p){ if(shell.sessions.isNotEmpty) shell.startBooking(shell.sessions.firstWhere((s)=>s['provider_id']==p['id'], orElse:()=>shell.sessions.first), p); }),
      DiscountStrip(ads:shell.ads),
      SectionTitle(title:'أفكار وإلهام', icon:Icons.lightbulb_outline, onAll:(){}),
      IdeasGrid(sessions:shell.sessions),
      const SizedBox(height:120),
    ]));
  }
}

class AppHeader extends StatelessWidget { final _CustomerShellState shell; final String title, subtitle; final bool showSearch; const AppHeader({super.key,required this.shell,required this.title,required this.subtitle,this.showSearch=false});
  @override Widget build(BuildContext context){
    return Container(
      padding: const EdgeInsets.fromLTRB(18,18,18,24),
      decoration: const BoxDecoration(color:C.navy, borderRadius: BorderRadius.vertical(bottom: Radius.circular(34))),
      child: Column(children:[
        Row(children:[
          InkWell(onTap:shell.openLocation, borderRadius:BorderRadius.circular(18), child: Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:10), decoration:BoxDecoration(border:Border.all(color:C.gold), borderRadius:BorderRadius.circular(18)), child: Row(children:[const Icon(Icons.location_on,color:C.gold), const SizedBox(width:6), Text(shell.area,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w900)), const Icon(Icons.keyboard_arrow_down,color:Colors.white)]))),
          const Spacer(), IconButton(onPressed:shell.openFavorites, icon:const Icon(Icons.favorite_border,color:Colors.white)), Stack(children:[IconButton(onPressed:shell.notify, icon:const Icon(Icons.notifications_none,color:Colors.white)), if(shell.notifications.where((n)=>n['read']==false).isNotEmpty) Positioned(top:6,right:6, child: CircleAvatar(radius:10, backgroundColor:C.purple2, child:Text('${shell.notifications.where((n)=>n['read']==false).length}', style:const TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.bold))))])
        ]),
        const SizedBox(height:6),
        Container(padding: const EdgeInsets.symmetric(horizontal:24, vertical:8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2)), child: Column(children: const [Text('صورني', style:TextStyle(color:C.ink,fontSize:34,fontWeight:FontWeight.w900)), Text('SAWRNI', style:TextStyle(color:C.gold,fontSize:16,letterSpacing:4,fontWeight:FontWeight.w700))])),
        const SizedBox(height:10), Text(subtitle, style: const TextStyle(color:C.gold,fontWeight:FontWeight.w900,fontSize:18)),
        if(showSearch) ...[const SizedBox(height:18), SearchBarWidget(onChanged:shell.runSearch,onFilter:shell.openFilters)]
      ]),
    );
  }
}

class SearchBarWidget extends StatelessWidget { final ValueChanged<String> onChanged; final VoidCallback onFilter; const SearchBarWidget({super.key,required this.onChanged,required this.onFilter});
  @override Widget build(BuildContext context){
    return Container(decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(34),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.12),blurRadius:20)]), child: TextField(onChanged:onChanged, textInputAction:TextInputAction.search, decoration:InputDecoration(prefixIcon:const Icon(Icons.search,size:30), suffixIcon:IconButton(onPressed:onFilter, icon:const Icon(Icons.tune_rounded)), hintText:'إبحث عن جلسة، موديل، أو مصور', border:InputBorder.none, contentPadding:const EdgeInsets.symmetric(vertical:18), hintStyle:const TextStyle(color:C.muted,fontWeight:FontWeight.w600))));
  }
}

class CategoryChips extends StatelessWidget { final List categories; final String selected; final Function(String) onTap; const CategoryChips({super.key,required this.categories,required this.selected,required this.onTap});
  @override Widget build(BuildContext context){
    return SizedBox(height:68, child: ListView.separated(reverse:true, scrollDirection:Axis.horizontal, padding:const EdgeInsets.symmetric(horizontal:16,vertical:12), itemBuilder:(_,i){ final c=categories[i]; final a=c['id']==selected; return InkWell(onTap:()=>onTap(c['id']), borderRadius:BorderRadius.circular(24), child: AnimatedContainer(duration:const Duration(milliseconds:220), padding:const EdgeInsets.symmetric(horizontal:16), decoration:BoxDecoration(color:a?C.purple:Colors.white,borderRadius:BorderRadius.circular(24),border:Border.all(color:a?C.purple:C.line),boxShadow:[BoxShadow(color:(a?C.purple:Colors.black).withOpacity(a ? .18 : .06),blurRadius:18,offset:const Offset(0,8))]), child:Row(children:[Text(c['icon']??'',style:const TextStyle(fontSize:18)), const SizedBox(width:6), Text(c['name']??'',style:TextStyle(color:a?Colors.white:C.ink,fontWeight:FontWeight.w900))]))); }, separatorBuilder:(_,__)=>const SizedBox(width:8), itemCount:categories.length));
  }
}

class ModelRow extends StatelessWidget { final List models; final Function(Map) onTap; const ModelRow({super.key,required this.models,required this.onTap});
  @override Widget build(BuildContext context){
    return SizedBox(height:112, child: ListView.separated(reverse:true, scrollDirection:Axis.horizontal, padding:const EdgeInsets.symmetric(horizontal:18,vertical:8), itemCount:models.length, separatorBuilder:(_,__)=>const SizedBox(width:10), itemBuilder:(_,i){ final m=Map.from(models[i]); return GestureDetector(onTap:()=>onTap(m), child: Stack(clipBehavior:Clip.none, children:[Container(width:82, decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.10),blurRadius:16,offset:const Offset(0,8))]), padding:const EdgeInsets.all(5), child: ClipRRect(borderRadius:BorderRadius.circular(18), child: SmartImage(url:m['photo'], height:88, width:72))), Positioned(bottom:2,right:4, child:CircleAvatar(radius:15,backgroundColor:C.purple,child:const Icon(Icons.chevron_left,color:Colors.white,size:22)))])); }));
  }
}

class HeroCarousel extends StatelessWidget {
  final List ads;
  final Map category;
  final List sessions;
  final VoidCallback onBook;
  const HeroCarousel({super.key, required this.ads, required this.category, required this.sessions, required this.onBook});

  @override
  Widget build(BuildContext context) {
    final list = ads.isNotEmpty ? ads : sessions;
    if (list.isEmpty) {
      return const SizedBox(
        height: 188,
        child: Center(child: Text('لا توجد عروض حالياً', style: TextStyle(color: C.muted))),
      );
    }
    final count = list.length.clamp(1, 5).toInt();
    return SizedBox(
      height: 188,
      child: PageView.builder(
        controller: PageController(viewportFraction: .92),
        reverse: true,
        itemCount: count,
        itemBuilder: (_, i) {
          final x = list[i % list.length];
          final image = x['image'] ?? x['photo'];
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              boxShadow: [BoxShadow(color: C.navy.withOpacity(.18), blurRadius: 26, offset: const Offset(0, 12))],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  SmartImage(url: image, height: 188),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [C.navy.withOpacity(.90), C.navy.withOpacity(.40), Colors.transparent],
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          x['title'] ?? category['hero_title'] ?? '',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 28, height: 1.15),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          x['subtitle'] ?? category['hero_subtitle'] ?? '',
                          style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700),
                        ),
                        const Spacer(),
                        ElevatedButton.icon(
                          onPressed: onBook,
                          icon: const Icon(Icons.chevron_left),
                          label: const Text('احجز جلستك الآن'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: C.gold2,
                            foregroundColor: C.ink,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 12,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        4,
                        (d) => Container(
                          width: d == i % 4 ? 20 : 8,
                          height: 8,
                          margin: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(d == i % 4 ? 1 : .5),
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class SectionTitle extends StatelessWidget { final String title; final IconData icon; final VoidCallback onAll; const SectionTitle({super.key,required this.title,required this.icon,required this.onAll}); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(18,24,18,10), child:Row(children:[Icon(icon,color:C.gold), const SizedBox(width:8), Text(title, style:const TextStyle(fontWeight:FontWeight.w900,fontSize:26,color:C.ink)), const Spacer(), TextButton.icon(onPressed:onAll, icon:const Icon(Icons.chevron_left), label:const Text('عرض الكل'), style:TextButton.styleFrom(foregroundColor:C.purple))])); }

class HorizontalCards extends StatelessWidget { final List items; final Set<String> favorites; final Function(String) onFav; final Function(Map) onTap; const HorizontalCards({super.key,required this.items,required this.favorites,required this.onFav,required this.onTap});
  @override Widget build(BuildContext context){
    return SizedBox(height:170, child: ListView.separated(reverse:true, scrollDirection:Axis.horizontal, padding:const EdgeInsets.symmetric(horizontal:18), itemCount:items.length, separatorBuilder:(_,__)=>const SizedBox(width:12), itemBuilder:(_,i){ final s=Map.from(items[i]); return GestureDetector(onTap:()=>onTap(s), child:Container(width:190, decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.12),blurRadius:18,offset:const Offset(0,8))]), child:ClipRRect(borderRadius:BorderRadius.circular(22), child:Stack(fit:StackFit.expand, children:[SmartImage(url:s['photo'],height:170), Container(decoration:BoxDecoration(gradient:LinearGradient(colors:[Colors.transparent,Colors.black.withOpacity(.85)],begin:Alignment.topCenter,end:Alignment.bottomCenter))), Positioned(top:8,right:8, child:BadgeChip(text:s['available_today']==true?'متاح اليوم':'مميز', color:C.gold)), Positioned(top:8,left:8, child:IconButton(onPressed:()=>onFav(s['id']), icon:Icon(favorites.contains(s['id'])?Icons.favorite:Icons.favorite_border,color:Colors.white))), Positioned(bottom:12,right:12,left:12, child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Text(s['title']??'', maxLines:1, overflow:TextOverflow.ellipsis, style:const TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w900)), Text('${fmt(s['price_iqd'])} د.ع', style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700))]))])))); }));
  }
}

class PhotographerRow extends StatelessWidget { final List providers; final Set<String> favorites; final Function(String) onFav; final Function(Map) onTap; const PhotographerRow({super.key,required this.providers,required this.favorites,required this.onFav,required this.onTap});
  @override Widget build(BuildContext context){ return SizedBox(height:158, child:ListView.separated(reverse:true,scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:18),itemCount:providers.length,separatorBuilder:(_,__)=>const SizedBox(width:12),itemBuilder:(_,i){ final p=Map.from(providers[i]); return InkWell(onTap:()=>onTap(p),borderRadius:BorderRadius.circular(22),child:Container(width:132,padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22),border:Border.all(color:C.line),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.06),blurRadius:18)]),child:Column(children:[Stack(children:[CircleAvatar(radius:34,backgroundColor:C.bg,backgroundImage:NetworkImage(p['avatar']??'')),Positioned(bottom:0,right:0,child:Container(padding:const EdgeInsets.symmetric(horizontal:6,vertical:2),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(10)),child:Row(children:[const Icon(Icons.star,color:C.gold,size:14),Text('${p['rating']}',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:12))])))]),const SizedBox(height:8),Text(p['name']??'',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900)),Text((p['category_ids'] as List? ?? []).isNotEmpty ? 'تصوير ${(p['category_ids'] as List).first}' : 'مصور',style:const TextStyle(color:C.muted,fontSize:12)),IconButton(onPressed:()=>onFav(p['id']),icon:Icon(favorites.contains(p['id'])?Icons.favorite:Icons.favorite_border,color:favorites.contains(p['id'])?C.red:C.muted))]))); })); }
}

class DiscountStrip extends StatelessWidget { final List ads; const DiscountStrip({super.key,required this.ads}); @override Widget build(BuildContext context){ return SizedBox(height:98, child:ListView.separated(reverse:true,scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:18,vertical:12),itemCount:ads.length,separatorBuilder:(_,__)=>const SizedBox(width:12),itemBuilder:(_,i){ final a=ads[i]; return Container(width:330,decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[C.navy,C.purple]),boxShadow:[BoxShadow(color:C.purple.withOpacity(.22),blurRadius:24)]),child:ClipRRect(borderRadius:BorderRadius.circular(22),child:Stack(children:[Positioned.fill(child:Opacity(opacity:.35,child:SmartImage(url:a['image'],height:98))),Padding(padding:const EdgeInsets.all(16),child:Row(children:[const Icon(Icons.card_giftcard,color:C.gold,size:46),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(a['title']??'عرض',style:const TextStyle(color:C.gold,fontSize:22,fontWeight:FontWeight.w900)),Text(a['subtitle']??'',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700),maxLines:1,overflow:TextOverflow.ellipsis)])),Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:C.purple,borderRadius:BorderRadius.circular(16)),child:Text('${a['discount_percent']??0}%',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:20)))]) )]))); })); }}

class IdeasGrid extends StatelessWidget { final List sessions; const IdeasGrid({super.key,required this.sessions}); @override Widget build(BuildContext context){ final list=sessions.take(6).toList(); return GridView.builder(padding:const EdgeInsets.symmetric(horizontal:18),shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:1.7,crossAxisSpacing:12,mainAxisSpacing:12),itemCount:list.length,itemBuilder:(_,i){ final s=list[i]; return ClipRRect(borderRadius:BorderRadius.circular(20),child:Stack(fit:StackFit.expand,children:[SmartImage(url:s['photo'],height:110),Container(decoration:BoxDecoration(gradient:LinearGradient(colors:[Colors.transparent,Colors.black.withOpacity(.75)],begin:Alignment.topCenter,end:Alignment.bottomCenter))),Positioned(bottom:12,right:12,left:12,child:Text(s['title']??'',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:18),maxLines:1,overflow:TextOverflow.ellipsis))])); }); }}

class SessionsPage extends StatelessWidget { final _CustomerShellState shell; const SessionsPage({super.key,required this.shell}); @override Widget build(BuildContext context){ return RefreshIndicator(onRefresh:shell.loadAll,color:C.purple,child:ListView(padding:const EdgeInsets.fromLTRB(18,18,18,130),children:[PageHeader(title:'الجلسات',subtitle:'اختر باقة جاهزة أو احجز من مصور معتمد'),SearchBarWidget(onChanged:shell.runSearch,onFilter:shell.openFilters),const SizedBox(height:18),...shell.sessions.map((s)=>SessionListTile(session:Map.from(s),onTap:()=>shell.startBooking(Map.from(s)),onFav:()=>shell.toggleFavorite(s['id']),saved:shell.favorites.contains(s['id'])))])); }}
class ModelsPage extends StatelessWidget { final _CustomerShellState shell; const ModelsPage({super.key,required this.shell}); @override Widget build(BuildContext context){ return ListView(padding:const EdgeInsets.fromLTRB(18,18,18,130),children:[PageHeader(title:'الموديلز',subtitle:'اختر موديل للجلسات الإعلانية أو الشخصية'),GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.78,crossAxisSpacing:12,mainAxisSpacing:12),itemCount:shell.models.length,itemBuilder:(_,i){final m=Map.from(shell.models[i]);return GestureDetector(onTap:()=>showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(_)=>ModelProfile(model:m,onBook:(){Navigator.pop(context); if(shell.sessions.isNotEmpty) shell.startBooking(shell.sessions.first);})),child:Container(decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.07),blurRadius:18)]),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[ClipRRect(borderRadius:const BorderRadius.vertical(top:Radius.circular(24)),child:SmartImage(url:m['photo'],height:150)),Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(m['name']??'',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:18)),Text(m['bio']??'',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:C.muted)),const SizedBox(height:6),Text('${fmt(m['rate_iqd'])} د.ع',style:const TextStyle(color:C.purple,fontWeight:FontWeight.w900))]))])));})]); }}
class BookingsPage extends StatelessWidget { final _CustomerShellState shell; const BookingsPage({super.key,required this.shell}); @override Widget build(BuildContext context){ return RefreshIndicator(onRefresh:shell.loadAll,color:C.purple,child:ListView(padding:const EdgeInsets.fromLTRB(18,18,18,130),children:[PageHeader(title:'حجوزاتي',subtitle:'تابع الطلبات، الدفع، والتسليم'),...shell.bookings.map((b)=>BookingTile(booking:Map.from(b),onTap:()=>showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(_)=>BookingTrackSheet(booking:Map.from(b)))))])); }}
class AccountPage extends StatelessWidget { final _CustomerShellState shell; const AccountPage({super.key,required this.shell}); @override Widget build(BuildContext context){ return ListView(padding:const EdgeInsets.fromLTRB(18,18,18,130),children:[PageHeader(title:'حسابي',subtitle:'إدارة حسابك وعناوينك ومحفظتك'),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(26),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.06),blurRadius:20)]),child:Column(children:[Container(padding:const EdgeInsets.symmetric(horizontal:24,vertical:8),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:C.line),borderRadius:BorderRadius.circular(8)),child:const Text('صورني\nSAWRNI',textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.w900,color:C.ink))),const SizedBox(height:12),const Text('مستخدم تجريبي',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const Text('Android Flutter V17 - متصل بالباكند',style:TextStyle(color:C.muted)),const SizedBox(height:18),OutlinedButton.icon(onPressed:()=>Api.get('ping').then((v)=>shell.toast(v['message']??'API')),icon:const Icon(Icons.api),label:const Text('افحص رابط API')),const SizedBox(height:8),OutlinedButton.icon(onPressed:shell.openLocation,icon:const Icon(Icons.location_on_outlined),label:Text('الموقع الحالي: ${shell.area}')),const Divider(),MenuRow(title:'المفضلة',icon:Icons.favorite_border,onTap:shell.openFavorites),MenuRow(title:'الإشعارات',icon:Icons.notifications_none,onTap:shell.notify),MenuRow(title:'العناوين المحفوظة',icon:Icons.map_outlined,onTap:shell.openLocation),MenuRow(title:'الإعدادات',icon:Icons.settings_outlined,onTap:()=>shell.toast('تم فتح إعدادات تجريبية'))]))]); }}

class PageHeader extends StatelessWidget { final String title,subtitle; const PageHeader({super.key,required this.title,required this.subtitle}); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:36,fontWeight:FontWeight.w900,color:C.ink)),const SizedBox(height:4),Text(subtitle,style:const TextStyle(color:C.muted,fontWeight:FontWeight.w700))])); }
class SessionListTile extends StatelessWidget { final Map session; final VoidCallback onTap,onFav; final bool saved; const SessionListTile({super.key,required this.session,required this.onTap,required this.onFav,required this.saved}); @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(26),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.06),blurRadius:18)]),child:Row(children:[ClipRRect(borderRadius:BorderRadius.circular(18),child:SmartImage(url:session['photo'],width:96,height:96)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(session['title']??'',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:20)),Text((session['tags'] as List? ?? []).join(' • '),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:C.muted)),Text('${fmt(session['price_iqd'])} د.ع',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:20,color:C.ink))])),IconButton(onPressed:onFav,icon:Icon(saved?Icons.favorite:Icons.favorite_border,color:saved?C.red:C.muted)),ElevatedButton(onPressed:onTap,style:ElevatedButton.styleFrom(backgroundColor:C.gold2,foregroundColor:C.ink,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),child:const Text('احجز',style:TextStyle(fontWeight:FontWeight.w900)))])); }
class BookingTile extends StatelessWidget { final Map booking; final VoidCallback onTap; const BookingTile({super.key,required this.booking,required this.onTap}); @override Widget build(BuildContext context){ final s=booking['session']??{}; return InkWell(onTap:onTap,borderRadius:BorderRadius.circular(24),child:Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.05),blurRadius:16)]),child:Row(children:[ClipRRect(borderRadius:BorderRadius.circular(16),child:SmartImage(url:s['photo'],width:72,height:72)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(booking['id']??'',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('${booking['date']} ${booking['time']}',style:const TextStyle(color:C.muted)),BadgeChip(text:booking['status']??'', color:booking['status']=='confirmed'?C.green:C.gold)])),Text('${fmt(booking['price_iqd'])} د.ع',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:18))]))); }}
class MenuRow extends StatelessWidget { final String title; final IconData icon; final VoidCallback onTap; const MenuRow({super.key,required this.title,required this.icon,required this.onTap}); @override Widget build(BuildContext context)=>ListTile(onTap:onTap,leading:Icon(icon,color:C.purple),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),trailing:const Icon(Icons.chevron_left)); }
class BadgeChip extends StatelessWidget { final String text; final Color color; const BadgeChip({super.key,required this.text,required this.color}); @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),decoration:BoxDecoration(color:color.withOpacity(.18),borderRadius:BorderRadius.circular(999)),child:Text(text,style:TextStyle(color:color==C.gold?Colors.brown:color,fontWeight:FontWeight.w900,fontSize:12))); }
class SmartImage extends StatelessWidget { final String? url; final double? height,width; const SmartImage({super.key,this.url,this.height,this.width}); @override Widget build(BuildContext context){ if(url==null||url!.isEmpty){return PlaceholderBox(height:height,width:width);} return Image.network(url!,height:height,width:width,fit:BoxFit.cover,alignment:Alignment.center,errorBuilder:(_,__,___)=>PlaceholderBox(height:height,width:width),loadingBuilder:(c,child,progress)=>progress==null?child:PlaceholderBox(height:height,width:width,loading:true)); }}
class PlaceholderBox extends StatelessWidget { final double? height,width; final bool loading; const PlaceholderBox({super.key,this.height,this.width,this.loading=false}); @override Widget build(BuildContext context)=>Container(height:height,width:width,decoration:const BoxDecoration(gradient:LinearGradient(colors:[C.navy,C.purple])),child:Center(child:loading?const CircularProgressIndicator(color:Colors.white):const Icon(Icons.camera_alt,color:Colors.white70,size:36))); }
class ErrorState extends StatelessWidget { final String error; final VoidCallback onRetry; const ErrorState({super.key,required this.error,required this.onRetry}); @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.wifi_off,color:C.red,size:56),const SizedBox(height:12),const Text('تعذر الاتصال بالباكند',style:TextStyle(fontWeight:FontWeight.w900,fontSize:24)),Text(error,textAlign:TextAlign.center,style:const TextStyle(color:C.muted)),const SizedBox(height:18),ElevatedButton(onPressed:onRetry,child:const Text('إعادة المحاولة'))]))); }

class LocationSheet extends StatelessWidget { final List areas; final String selected; const LocationSheet({super.key,required this.areas,required this.selected}); @override Widget build(BuildContext context)=>Sheet(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('اختر المنطقة',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:areas.map((a)=>ChoiceChip(label:Text('$a'),selected:a==selected,onSelected:(_)=>Navigator.pop(context,'$a'),selectedColor:C.purple,labelStyle:TextStyle(color:a==selected?Colors.white:C.ink,fontWeight:FontWeight.w800))).toList())])); }
class FilterSheet extends StatelessWidget { final List categories,areas; final String category,area; final void Function(String,String) onApply; const FilterSheet({super.key,required this.categories,required this.areas,required this.category,required this.area,required this.onApply}); @override Widget build(BuildContext context){ String c=category,a=area; return StatefulBuilder(builder:(context,set)=>Sheet(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('تصفية النتائج',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:12),const Text('التصنيف',style:TextStyle(fontWeight:FontWeight.w800)),Wrap(spacing:8,children:categories.map((x)=>ChoiceChip(label:Text(x['name']),selected:c==x['id'],onSelected:(_)=>set(()=>c=x['id']),selectedColor:C.purple,labelStyle:TextStyle(color:c==x['id']?Colors.white:C.ink))).toList()),const SizedBox(height:14),const Text('المنطقة',style:TextStyle(fontWeight:FontWeight.w800)),Wrap(spacing:8,children:areas.map((x)=>ChoiceChip(label:Text('$x'),selected:a==x,onSelected:(_)=>set(()=>a='$x'),selectedColor:C.gold2)).toList()),const SizedBox(height:18),SizedBox(width:double.infinity,child:ElevatedButton(onPressed:(){Navigator.pop(context);onApply(c,a);},style:ElevatedButton.styleFrom(backgroundColor:C.purple,foregroundColor:Colors.white,padding:const EdgeInsets.all(16)),child:const Text('تطبيق',style:TextStyle(fontWeight:FontWeight.w900))))]))); }}
class NotificationSheet extends StatelessWidget { final List items; const NotificationSheet({super.key,required this.items}); @override Widget build(BuildContext context)=>Sheet(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('الإشعارات',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:12),...items.map((n)=>ListTile(leading:CircleAvatar(backgroundColor:C.purple.withOpacity(.12),child:const Icon(Icons.notifications,color:C.purple)),title:Text(n['title']??'',style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('${n['body']??''}\n${n['created_at']??''}')))])); }
class FavoritesPage extends StatelessWidget { final Set<String> favorites; final List sessions,providers,models; final Function(String) onFav; const FavoritesPage({super.key,required this.favorites,required this.sessions,required this.providers,required this.models,required this.onFav}); @override Widget build(BuildContext context){ final favSessions=sessions.where((x)=>favorites.contains(x['id'])).toList(); return Scaffold(backgroundColor:C.bg,appBar:AppBar(title:const Text('المفضلة')),body:ListView(padding:const EdgeInsets.all(18),children:[...favSessions.map((s)=>SessionListTile(session:Map.from(s),onTap:(){},onFav:()=>onFav(s['id']),saved:true)), if(favSessions.isEmpty) const Center(child:Padding(padding:EdgeInsets.all(40),child:Text('لا توجد عناصر محفوظة بعد')))])); }}
class ModelProfile extends StatelessWidget { final Map model; final VoidCallback onBook; const ModelProfile({super.key,required this.model,required this.onBook}); @override Widget build(BuildContext context)=>Sheet(child:Column(mainAxisSize:MainAxisSize.min,children:[ClipRRect(borderRadius:BorderRadius.circular(24),child:SmartImage(url:model['photo'],height:230,width:double.infinity)),const SizedBox(height:12),Text(model['name']??'',style:const TextStyle(fontSize:32,fontWeight:FontWeight.w900)),Text(model['bio']??'',style:const TextStyle(color:C.muted)),const SizedBox(height:12),Row(mainAxisAlignment:MainAxisAlignment.center,children:[BadgeChip(text:'موثق',color:C.green),const SizedBox(width:8),BadgeChip(text:'${fmt(model['rate_iqd'])} د.ع',color:C.gold)]),const SizedBox(height:18),SizedBox(width:double.infinity,child:ElevatedButton.icon(onPressed:onBook,icon:const Icon(Icons.camera_alt),label:const Text('احجز مع هذا الموديل'),style:ElevatedButton.styleFrom(backgroundColor:C.purple,foregroundColor:Colors.white,padding:const EdgeInsets.all(16),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)))))])); }
class BookingSheet extends StatefulWidget { final Map session; final List providers; final Map? selectedProvider; final String area; const BookingSheet({super.key,required this.session,required this.providers,this.selectedProvider,required this.area}); @override State<BookingSheet> createState()=>_BookingSheetState(); }
class _BookingSheetState extends State<BookingSheet>{ late Map provider; String date='2026-07-02',time='17:00',area='',location='جامعة بغداد'; @override void initState(){super.initState(); area=widget.area; provider=widget.selectedProvider ?? widget.providers.cast<Map>().firstWhere((p)=>p['id']==widget.session['provider_id'],orElse:()=>widget.providers.isNotEmpty?widget.providers.first:{});}
  @override Widget build(BuildContext context)=>Sheet(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[ClipRRect(borderRadius:BorderRadius.circular(24),child:SmartImage(url:widget.session['photo'],height:180,width:double.infinity)),const SizedBox(height:12),Text(widget.session['title']??'',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),Text(provider['name']??'اختر مصور',style:const TextStyle(color:C.muted,fontWeight:FontWeight.w700)),const SizedBox(height:12),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(border:Border.all(color:C.line),borderRadius:BorderRadius.circular(20)),child:Column(children:[InfoRow(label:'السعر الكامل',value:'${fmt(widget.session['price_iqd'])} د.ع'),InfoRow(label:'العربون',value:'${fmt(widget.session['deposit_iqd'])} د.ع'),const InfoRow(label:'قابل للتعديل',value:'خلال 3 ساعات من الدفع')])),const SizedBox(height:12),Row(children:[Expanded(child:TextField(controller:TextEditingController(text:date),onChanged:(v)=>date=v,decoration:const InputDecoration(labelText:'التاريخ',border:OutlineInputBorder()))),const SizedBox(width:10),Expanded(child:TextField(controller:TextEditingController(text:time),onChanged:(v)=>time=v,decoration:const InputDecoration(labelText:'الوقت',border:OutlineInputBorder())))]),const SizedBox(height:10),TextField(controller:TextEditingController(text:location),onChanged:(v)=>location=v,decoration:const InputDecoration(labelText:'الموقع التفصيلي',border:OutlineInputBorder())),const SizedBox(height:18),Row(children:[Expanded(child:ElevatedButton.icon(onPressed:(){Navigator.pop(context,{'customer_id':SawrniConfig.customerId,'customer_name':SawrniConfig.customerName,'session_id':widget.session['id'],'provider_id':provider['id'],'date':date,'time':time,'area':area,'location_detail':location});},icon:const Icon(Icons.check),label:const Text('تأكيد الحجز'),style:ElevatedButton.styleFrom(backgroundColor:C.purple,foregroundColor:Colors.white,padding:const EdgeInsets.all(16)))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.person_search),label:const Text('عرض المصور'),style:OutlinedButton.styleFrom(padding:const EdgeInsets.all(16))))])])); }
class BookingTrackSheet extends StatelessWidget { final Map booking; const BookingTrackSheet({super.key,required this.booking}); @override Widget build(BuildContext context){ final steps=(booking['timeline'] as List? ?? []); return Sheet(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text('تتبع الطلب ${booking['id']}',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:12),...steps.map((s)=>ListTile(leading:const CircleAvatar(backgroundColor:C.green,child:Icon(Icons.check,color:Colors.white)),title:Text('$s',style:const TextStyle(fontWeight:FontWeight.w800)))),const SizedBox(height:10),ElevatedButton(onPressed:()=>Navigator.pop(context),style:ElevatedButton.styleFrom(backgroundColor:C.purple,foregroundColor:Colors.white),child:const Text('إغلاق'))])); }}
class Sheet extends StatelessWidget { final Widget child; const Sheet({super.key,required this.child}); @override Widget build(BuildContext context)=>Container(maxHeight:MediaQuery.of(context).size.height*.88,padding:const EdgeInsets.fromLTRB(18,12,18,24),decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(34))),child:SingleChildScrollView(child:Column(children:[Container(width:54,height:5,decoration:BoxDecoration(color:C.line,borderRadius:BorderRadius.circular(20))),const SizedBox(height:18),child]))); }
class InfoRow extends StatelessWidget { final String label,value; const InfoRow({super.key,required this.label,required this.value}); @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Row(children:[Text(label,style:const TextStyle(color:C.muted,fontWeight:FontWeight.w700)),const Spacer(),Text(value,style:const TextStyle(fontWeight:FontWeight.w900))])); }
