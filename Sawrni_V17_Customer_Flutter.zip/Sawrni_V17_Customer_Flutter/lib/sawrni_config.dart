class SawrniConfig {
  // Change this after uploading the Hostinger backend package.
  // Example: https://your-domain.com/api.php
  static const String apiBaseUrl = 'https://aquamarine-jellyfish-708888.hostingersite.com/api.php';
  static const String customerId = 'c1';
  static const String customerName = 'مستخدم تجريبي';
}
