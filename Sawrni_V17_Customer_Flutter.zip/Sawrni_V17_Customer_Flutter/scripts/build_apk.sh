#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PATH="/workspaces/flutter/bin:$PATH"
if [ ! -d android ]; then
  flutter create . --platforms=android --org com.sawrni.app
fi
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
if p.exists():
    s=p.read_text()
    if 'usesCleartextTraffic' not in s:
        s=s.replace('<application', '<application android:usesCleartextTraffic="true"')
    p.write_text(s)
PY
flutter clean
flutter pub get
flutter build apk --debug
mkdir -p "$ROOT/apk-output"
cp build/app/outputs/flutter-apk/app-debug.apk "$ROOT/apk-output/Sawrni_Debug.apk"
ls -lh "$ROOT/apk-output/Sawrni_Debug.apk"
